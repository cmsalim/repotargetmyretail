package com.myRetail.application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myRetail.application.model.Price;

public interface PriceRepository extends JpaRepository<Price, Integer>{

}
