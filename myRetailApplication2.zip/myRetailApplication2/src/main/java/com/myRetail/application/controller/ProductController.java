package com.myRetail.application.controller;




import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.myRetail.application.exception.ResourceNotFoundException;
import com.myRetail.application.model.Price;
import com.myRetail.application.model.Product;
import com.myRetail.application.service.ProductService;

@RestController
@RequestMapping("/myRetail/v1/")
public class ProductController {
	
	//Map<String , Product> product;
	private ProductService productService;
	
	@Autowired
	public ProductController(ProductService theProductService) {
		productService=theProductService;
	}
	
	
	@GetMapping(path = "product/{id}" , produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Product> getProductDetailsById (@PathVariable(value = "id") int id) throws ResourceNotFoundException{
		
		RestTemplate restTemplate = new RestTemplate();
		String productName = restTemplate.getForObject("http://localhost:8080/myRetail/v1//getProductName/"+id, String.class);
		Price priceDetails = productService.findById(id);
		Product product = new Product(id, productName, priceDetails);
		return ResponseEntity.ok(product);
	}
	
	
	
	@PutMapping(path = "product/{id}" ,consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Product> updateProdductPrice(@PathVariable int id, @Valid @RequestBody Product thepProduct) {
		
		RestTemplate restTemplate = new RestTemplate();
		String productName = restTemplate.getForObject("http://localhost:8080/myRetail/v1//getProductName/"+id, String.class);
		Price thePrice = productService.findById(id);
		Price newPrice= thepProduct.getCurrent_price();
		thePrice.setValue(newPrice.getValue());
		productService.save(thePrice);
		
		//Price thePrice=thepProduct.getCurrent_price();
		Product product=new Product(id, productName, thePrice);
	
		return ResponseEntity.ok(product);
		
	}
	
	
	
	
	@GetMapping(path = "getProductName/{id}" , produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<String> getProductName(@PathVariable (value = "id") int id)throws ResourceNotFoundException{
		
		if(id == 1231) {return ResponseEntity.ok("Men's 9\" Lined Run Shorts");}
		if(id == 1232) {return ResponseEntity.ok("Men's Jersey Polo Shirt");}
		if(id == 1233) {return ResponseEntity.ok("Men's Lightweight Run Pants");}
		if(id == 1234) {return ResponseEntity.ok("Men's Knit to Woven Jogger Pants");}
		if(id == 1235) {return ResponseEntity.ok("Men's Nylon Jogger Pants");}
		else {return ResponseEntity.ok("Product id invalid");}
	}
	
	
	

}
