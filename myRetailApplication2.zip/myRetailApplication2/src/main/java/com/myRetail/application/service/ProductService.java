package com.myRetail.application.service;


import com.myRetail.application.model.Price;


public interface ProductService {

	public Price findById(int theId);
	public void save(Price thePrice);
	public void deleteById(int theId);

}
