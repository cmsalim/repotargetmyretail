package com.myRetail.application.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myRetail.application.model.Price;
import com.myRetail.application.repository.PriceRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	private PriceRepository priceRepository;
	
	@Autowired
	public ProductServiceImpl(PriceRepository thePriceRepository) {
		priceRepository=thePriceRepository;
	}

	@Override
	public Price findById(int theId) {
		
		 Optional<Price> result = priceRepository.findById(theId);
		 Price thePrice = null;
		 if(result.isPresent()) {
			 thePrice = result.get();
		 } else
			 throw new RuntimeException("Did not find the product - " + theId);
		return thePrice;
	}

	@Override
	public void save(Price thePrice) {
		priceRepository.save(thePrice);
		
	}

	@Override
	public void deleteById(int theId) {
		priceRepository.deleteById(theId);
		
	}
	
	

}
