insert into price values (1231,'USD' , 20.00);
insert into price values(1232,'USD',30.00);
insert into price values(1233,'USD',42.35);
insert into price values(1234,'USD',48.00);
insert into price values(1235,'USD',26.33);